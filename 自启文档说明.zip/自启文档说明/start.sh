#!/bin/bash
echo "start running~~"
source /opt/ros/kinetic/setup.bash
source /home/tsintel/catkin_cz/devel/setup.bash

rosclean purge -y
roslaunch planning_control demo.launch

#gnome-terminal -x sudo -s /home/tsintel/catkin_cz/start.sh
#记得给本文件给权限 chmod -R 777 ./ 或 chmod +x start.sh
